import { QUESTIONS, QUESTION_HINTS, TYPE_LABEL } from './questions.js';
import { OUTCOMES } from './outcomes.js';
import { applyOutcome, nextTeam, save, load, clone } from './engine.js';
import { renderQuestionEditor, makeCustomQuestion, downloadQuestionSet, parseQuestionSet } from './question-editor.js';
import { HAUNTED_HOUSE_SVG } from './haunted-house.js';

const app = document.querySelector('#app');
const toastEl = document.querySelector('#toast');
let state = load() || null;
let pregameScreen = state ? 'game' : 'intro';
if(state?.questionPool){state.questionPool=state.questionPool.map(q=>({...q,hint:q.hint||QUESTION_HINTS[q.id]||''}));if(state.question)state.question={...state.question,hint:state.question.hint||QUESTION_HINTS[state.question.id]||''};}
let selectedWords = [];
let selectedChoice = state?.selectedChoice ?? null;
let toastTimer;
let soundEnabled = localStorage.getItem('midnight-candy-sound') !== 'off';
let reducedMotion = localStorage.getItem('midnight-candy-motion') === 'reduced';
const CUSTOM_KEY='midnight-candy-custom-questions-v1',QUESTION_SOURCE_KEY='midnight-candy-question-source-v1',QUESTION_SET_NAME_KEY='midnight-candy-question-set-name-v1',QUESTION_SETS_KEY='midnight-candy-question-sets-v1',ACTIVE_SET_KEY='midnight-candy-active-question-set-v1';
function loadCustomQuestions(){try{const list=JSON.parse(localStorage.getItem(CUSTOM_KEY)||'[]');return Array.isArray(list)?list:[]}catch{return []}}
function loadQuestionSets(){try{const sets=JSON.parse(localStorage.getItem(QUESTION_SETS_KEY)||'[]');return Array.isArray(sets)?sets.filter(s=>s&&typeof s.id==='string'&&Array.isArray(s.questions)):[]}catch{return []}}
let questionSets=loadQuestionSets();
let activeSetId=localStorage.getItem(ACTIVE_SET_KEY)||questionSets[0]?.id||'default-set';
if(!questionSets.length)questionSets=[{id:activeSetId,name:localStorage.getItem(QUESTION_SET_NAME_KEY)||'My Halloween questions',questions:loadCustomQuestions()}];
let activeSet=questionSets.find(s=>s.id===activeSetId)||questionSets[0];activeSetId=activeSet.id;
let customQuestions=activeSet.questions;
let questionSource=localStorage.getItem(QUESTION_SOURCE_KEY)==='custom'&&customQuestions.length?'custom':'built-in';
let editorOpen=false;
let editingQuestionIndex=null;
let confirmDeleteSet=false;
let questionSetName=activeSet.name||'My Halloween questions';
const TRICK_PRIZES=[{id:'trick-0',points:0,icon:'🕸️',label:'0 Candy · No candy found'},{id:'trick-10',points:10,icon:'🍬',label:'10 Candy'},{id:'trick-15',points:15,icon:'🍭',label:'15 Candy'},{id:'trick-20',points:20,icon:'🍫',label:'20 Candy'},{id:'trick-30',points:30,icon:'🍬',label:'30 Candy'},{id:'trick-50',points:50,icon:'🍭',label:'50 Candy'},{id:'trick-75',points:75,icon:'🍫',label:'75 Candy'},{id:'trick-100',points:100,icon:'🍬',label:'100 Candy jackpot'}];
const PRIZE_ODDS_KEY='midnight-candy-prize-odds-v4',PREVIOUS_PRIZE_ODDS_KEY='midnight-candy-prize-odds-v3',SECOND_PREVIOUS_PRIZE_ODDS_KEY='midnight-candy-prize-odds-v2',LEGACY_PRIZE_ODDS_KEY='midnight-candy-prize-odds-v1';
const defaultPrizeOdds={trick:{jackpot:3,blessing:15,gift:13,golden:6,vampire:10,skeleton:8,swap:7,heist:7,mayhem:8,haunted:6,moonlit:4,blackcat:4,bats:3,graveyard:1,midnight:1,'all-hallows-curse':4},treat:{'trick-0':5,'trick-10':20,'trick-15':20,'trick-20':20,'trick-30':15,'trick-50':10,'trick-75':5,'trick-100':5}};
function distributeOdds(weights,total){const entries=Object.entries(weights),sum=entries.reduce((n,[,value])=>n+Math.max(0,Number(value)||0),0),base=entries.map(([id,value])=>{const exact=(sum?Math.max(0,Number(value)||0)/sum:1/entries.length)*total;return{id,value:Math.floor(exact),remainder:exact-Math.floor(exact)}});let left=total-base.reduce((n,item)=>n+item.value,0);base.sort((a,b)=>b.remainder-a.remainder).slice(0,left).forEach(item=>item.value++);return Object.fromEntries(base.map(item=>[item.id,item.value]))}
function mergeTrickOdds(saved){const known=Object.fromEntries(Object.entries(saved||{}).filter(([id])=>id in defaultPrizeOdds.trick));const missing=Object.keys(defaultPrizeOdds.trick).filter(id=>!(id in known));if(!Object.keys(known).length)return{...defaultPrizeOdds.trick};if(!missing.length)return{...defaultPrizeOdds.trick,...known};const added=missing.reduce((sum,id)=>sum+defaultPrizeOdds.trick[id],0),old=distributeOdds(known,Math.max(0,100-added));return{...old,...Object.fromEntries(missing.map(id=>[id,defaultPrizeOdds.trick[id]]))}}
function loadPrizeOdds(){try{
 const saved=localStorage.getItem(PRIZE_ODDS_KEY);
 if(saved){const stored=JSON.parse(saved);return{trick:mergeTrickOdds(stored.trick),treat:{...defaultPrizeOdds.treat,...stored.treat}};}
 const previous=localStorage.getItem(PREVIOUS_PRIZE_ODDS_KEY),secondPrevious=localStorage.getItem(SECOND_PREVIOUS_PRIZE_ODDS_KEY),legacy=localStorage.getItem(LEGACY_PRIZE_ODDS_KEY);
 const old=JSON.parse(previous||secondPrevious||legacy||'{}'),version=previous?'v3':secondPrevious?'v2':legacy?'v1':null;
 const odds=version==='v1'?{trick:old.treat,treat:old.trick}:old;
 const oldTreatDefaults=version==='v3'?{'trick-10':50,'trick-15':30,'trick-25':15,'trick-60':5}:{'trick-10':25,'trick-20':25,'trick-30':25,'trick-50':25};
 const previousOutcomeIds=['jackpot','blessing','gift','golden','vampire','skeleton','swap','heist','mayhem','haunted'];
 const trickWasDefault=previousOutcomeIds.every(id=>Number(odds.trick?.[id])===10),treatWasDefault=Object.entries(oldTreatDefaults).every(([id,chance])=>Number(odds.treat?.[id])===chance);
 const migratedTreat=Object.fromEntries(TRICK_PRIZES.map(item=>[item.id,0]));
 if(version&&!treatWasDefault){const oldIds=Object.keys(oldTreatDefaults),nearest=points=>TRICK_PRIZES.reduce((best,item)=>Math.abs(item.points-points)<Math.abs(best.points-points)?item:best);oldIds.forEach(id=>{const target=nearest(Number(id.replace('trick-','')));migratedTreat[target.id]+=Number(odds.treat?.[id])||0;});}
 const result={trick:trickWasDefault?{...defaultPrizeOdds.trick}:mergeTrickOdds(odds.trick),treat:!version||treatWasDefault?{...defaultPrizeOdds.treat}:migratedTreat};
 if(version)localStorage.setItem(PRIZE_ODDS_KEY,JSON.stringify(result));
 return result;
}catch{return{trick:{...defaultPrizeOdds.trick},treat:{...defaultPrizeOdds.treat}}}}
let prizeOdds=loadPrizeOdds();
function chanceFor(group,id){return Number(prizeOdds[group]?.[id])||0}
function chooseByChance(items,group){const roll=Math.random()*100;let total=0;for(const item of items){total+=chanceFor(group,item.id);if(roll<total)return item;}return items.at(-1)}
function chooseDistinctByChance(items,group,count){const remaining=[...items],selected=[];while(selected.length<count&&remaining.length){const weights=remaining.map(item=>Math.max(0,chanceFor(group,item.id))),total=weights.reduce((sum,weight)=>sum+weight,0),roll=Math.random()*(total||remaining.length);let cumulative=0,index=remaining.length-1;for(let i=0;i<remaining.length;i++){cumulative+=total?weights[i]:1;if(roll<cumulative){index=i;break}}selected.push(remaining.splice(index,1)[0])}return selected}
const TRICK_CARD_THEMES=[
 {id:'candy',icon:'🍬',label:'Creepy Candy',clue:'A sweet rustle comes from inside…'},
 {id:'ghost-glow',icon:'👻',label:'Ghost Glow',clue:'A pale blue light flickers…'},
 {id:'black-cat',icon:'🐈‍⬛',label:'Black Cat Charm',clue:'Tiny pawprints appear nearby…'},
 {id:'potion',icon:'🧪',label:'Witch’s Potion',clue:'Bubbles pop in the dark…'},
 {id:'haunted-key',icon:'🗝️',label:'Haunted Key',clue:'Something behind the door rattles…'},
 {id:'raven-feather',icon:'🪶',label:'Raven Feather',clue:'A shadow circles overhead…'},
 {id:'spider-parcel',icon:'🕸️',label:'Spiderweb Parcel',clue:'The wrapping gives a little twitch…'},
 {id:'bone-box',icon:'💀',label:'Bone Box',clue:'A quiet clatter comes from within…'},
 {id:'bat-wing',icon:'🦇',label:'Bat Wing',clue:'Wings flutter just out of sight…'},
 {id:'moonlit-pumpkin',icon:'🌙',label:'Moonlit Pumpkin',clue:'A silver glow leaks through the cracks…'},
 {id:'graveyard-gift',icon:'⚰️',label:'Graveyard Gift',clue:'The earth shifts beneath it…'},
 {id:'mummy-wrap',icon:'🧻',label:'Mummy’s Parcel',clue:'The bandages are unravelling…'}
];
function chooseRandomDistinct(items,count){const remaining=[...items],chosen=[];while(chosen.length<count&&remaining.length)chosen.push(remaining.splice(Math.floor(Math.random()*remaining.length),1)[0]);return chosen}
if(state?.phase==='treat'&&!state.outcome&&Array.isArray(state.cards)){const unique=[...new Map(state.cards.map(card=>[card.id,card])).values()].slice(0,3),missing=3-unique.length;if(missing>0)unique.push(...chooseDistinctByChance(OUTCOMES.filter(item=>!unique.some(card=>card.id===item.id)),'trick',missing));state.cards=unique;if(!Array.isArray(state.trickCardThemes)||state.trickCardThemes.length!==3)state.trickCardThemes=chooseRandomDistinct(TRICK_CARD_THEMES,3);save(state)}
function oddsPanel(){const rows=(items,group)=>items.map(item=>`<label class="odds-row"><span>${item.icon||'🎃'} ${esc(item.label||item.name)}</span><input class="odds-input" data-odds-group="${group}" data-odds-id="${item.id}" type="number" min="0" max="100" step="1" value="${chanceFor(group,item.id)}" aria-label="${esc(item.label||item.name)} chance percentage"><b data-odds-value="${group}-${item.id}">${chanceFor(group,item.id)}%</b></label>`).join('');return `<details class="odds-settings"><summary>Customize prize chances</summary><p>Set each chance as a percentage. When you change one, the rest adjust to keep each group at 100%.</p><div class="odds-groups"><section><h3>TRICK · MYSTERY EVENTS</h3>${rows(OUTCOMES,'trick')}</section><section><h3>TREAT · CANDY BAG</h3>${rows(TRICK_PRIZES,'treat')}</section></div><div class="odds-footer"><p class="odds-save-note">These settings save on this device. Trick chances weight which three different events are offered; no event repeats in the same set. Treat chances weight the Candy prize.</p><button class="outline-btn" type="button" data-action="reset-odds">Reset chances to default</button></div></details>`}
function getStandings(teams){let previousScore=null,rank=0;return [...teams].map((team,seed)=>({...team,seed})).sort((a,b)=>b.score-a.score||a.seed-b.seed).map((team,index)=>{if(index===0||team.score<previousScore)rank=index+1;previousScore=team.score;return{id:team.id,name:team.name,score:team.score,rank,mascot:team.mascot}})}
function standingsSnapshot(teams){return getStandings(teams).map(({id,rank})=>({id,rank}))}
function rankMovement(teamId,previous,rank){const oldRank=previous?.find(item=>item.id===teamId)?.rank;if(!oldRank)return{className:'unchanged',label:'—',detail:'No previous position'};if(oldRank>rank)return{className:'moved-up',label:`▲ ${oldRank-rank}`,detail:`Up ${oldRank-rank} ${oldRank-rank===1?'place':'places'}`};if(oldRank<rank)return{className:'moved-down',label:`▼ ${rank-oldRank}`,detail:`Down ${rank-oldRank} ${rank-oldRank===1?'place':'places'}`};return{className:'unchanged',label:'—',detail:'Position unchanged'}}
if(reducedMotion) document.documentElement.classList.add('reduce-motion');
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function highlightChangedText(text, other, className) {
 const words = value => [...String(value).matchAll(/\S+/g)].map(match => ({ value: match[0], start: match.index, end: match.index + match[0].length }));
 const a = words(text), b = words(other);
 let prefix = 0;
 while (prefix < a.length && prefix < b.length && a[prefix].value === b[prefix].value) prefix++;
 let suffix = 0;
 while (suffix < a.length - prefix && suffix < b.length - prefix && a[a.length - 1 - suffix].value === b[b.length - 1 - suffix].value) suffix++;
 if (prefix === a.length && prefix === b.length) return esc(text);
 const start = prefix < a.length ? a[prefix].start : String(text).length;
 const end = suffix < a.length ? a[a.length - 1 - suffix].end : String(text).length;
 return `${esc(String(text).slice(0, start))}<mark class="${className}">${esc(String(text).slice(start, end)) || '∅'}</mark>${esc(String(text).slice(end))}`;
}
const current = () => state?.teams.find(t => t.id === state.currentTeamId);
function commit(next, undo = true) {
  if (undo && state) recordHistory(next, state);
  state = next; const saved=save(state); render(); if(!saved)notify('Browser storage is full. You can keep playing, but progress may not survive a refresh.');
}
function recordHistory(next, previous) {
  const snapshot = clone(previous);
  delete snapshot.history;
  if(snapshot.question?.id){snapshot.questionId=snapshot.question.id;delete snapshot.question;}
  delete snapshot.questionPool;
  next.history = [...(previous.history || []), snapshot].slice(-30);
}
function notify(message) {
  toastEl.textContent = message; toastEl.classList.add('show'); clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2400);
}
function playSound(kind='reveal') {
 if(!soundEnabled)return;
 try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;const ctx=new AC(),osc=ctx.createOscillator(),gain=ctx.createGain();const notes=kind==='correct'?[523,659,784]:kind==='trick'?[240,180,660]:kind==='turn'?[293,440,587]:[392,587,784];osc.type=kind==='trick'||kind==='turn'?'triangle':'sine';osc.frequency.setValueAtTime(notes[0],ctx.currentTime);notes.slice(1).forEach((n,i)=>osc.frequency.setValueAtTime(n,ctx.currentTime+.09*(i+1)));gain.gain.setValueAtTime(.0001,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.12,ctx.currentTime+.025);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.32);osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+.34);osc.onended=()=>ctx.close()}catch{}
}
function playPrizeSound(prize) {
 if(!soundEnabled)return;
 const profiles={jackpot:['triangle',[523,659,784,1047],.075],blessing:['sine',[392,523,659],.12],gift:['triangle',[440,554,659,880],.09],golden:['sine',[659,831,988,1318],.08],vampire:['sawtooth',[330,247,165,110],.09],skeleton:['square',[440,220,370,147],.065],swap:['triangle',[220,660,330,880],.075],heist:['sawtooth',[392,294,220,147],.1],mayhem:['triangle',[523,784,659,988,784,1175],.065],haunted:['sawtooth',[110,116,98,82],.16],'all-hallows-curse':['sawtooth',[196,147,110,73,55],.14]};
 const profile=profiles[prize];if(!profile){playSound('reveal');return;}
 try{
  const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
  const [wave,notes,step]=profile,ctx=new AC(),start=ctx.currentTime;
  notes.forEach((frequency,index)=>{const at=start+index*step,osc=ctx.createOscillator(),gain=ctx.createGain();osc.type=wave;osc.frequency.setValueAtTime(frequency,at);gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(['vampire','haunted'].includes(prize)?.055:.09,at+.012);gain.gain.exponentialRampToValueAtTime(.0001,at+.18);osc.connect(gain);gain.connect(ctx.destination);osc.start(at);osc.stop(at+.19);osc.onended=()=>{if(index===notes.length-1)setTimeout(()=>ctx.close(),240)}});
  if(['vampire','skeleton','heist','haunted','all-hallows-curse'].includes(prize)){const length=Math.floor(ctx.sampleRate*.28),buffer=ctx.createBuffer(1,length,ctx.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<length;i++)data[i]=(Math.random()*2-1)*(1-i/length);const noise=ctx.createBufferSource(),filter=ctx.createBiquadFilter(),gain=ctx.createGain();noise.buffer=buffer;filter.type='lowpass';filter.frequency.value=prize==='skeleton'?900:420;gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(prize==='skeleton'?.1:.07,start+.018);gain.gain.exponentialRampToValueAtTime(.0001,start+.26);noise.connect(filter);filter.connect(gain);gain.connect(ctx.destination);noise.start(start);noise.stop(start+.27)}
 }catch{}
}
const pumpkin = (n, used = false) => `<span class="pumpkin ${used?'is-used':''}"><span class="pumpkin-shape">&#127875;</span><b>${String(n).padStart(2,'0')}</b></span>`;
const QUESTION_MASCOTS = [
 { name: 'Vampire', emoji: '&#129499;' },
 { name: 'Werewolf', emoji: '&#128058;' },
 { name: 'Ghost', emoji: '&#128123;' },
 { name: 'Zombie', emoji: '&#129503;' },
 { name: 'Witch', emoji: '&#129497;' },
 { name: 'Monster', emoji: '&#129484;' }
];
const HALLOWEEN_JOKES = [
 { question: 'What is a ghost’s favorite food?', answer: 'Spook-etti!' },
 { question: 'What do you call a fat pumpkin?', answer: 'A plumpkin!' },
 { question: 'What is a witch’s favorite subject?', answer: 'Spelling!' },
 { question: 'What room does a ghost not need?', answer: 'A living room!' },
 { question: 'Why did the skeleton go alone to the party?', answer: 'He had no body to go with!' },
 { question: 'What is a ghost’s favorite drink?', answer: 'Boo-ble tea!' },
 { question: 'What do you call a witch at the beach?', answer: 'A sand-witch!' },
 { question: 'What is a ghost’s favorite game?', answer: 'Hide and shriek!' },
 { question: 'What is a skeleton’s favorite instrument?', answer: 'The trom-bone!' },
 { question: 'Why don’t mummies take holidays?', answer: 'They are afraid to unwind!' },
 { question: 'What is a vampire’s favorite fruit?', answer: 'A neck-tarine!' },
 { question: 'Why did the ghost go to school?', answer: 'To learn boo-kkeeping!' },
 { question: 'What do ghosts say when they meet?', answer: 'How boo you do?' }
];
function header() {
 return `<header class="topbar"><a class="brand" href="#"><span class="brand-icon">&#127875;</span><span><strong>MIDNIGHT CANDY</strong></span></a><div class="top-actions"><button class="icon-btn" data-action="sound-toggle" aria-pressed="${soundEnabled}">${soundEnabled?'&#128266;':'&#128263;'} <span>Sound ${soundEnabled?'on':'off'}</span></button><button class="icon-btn" data-action="motion-toggle" aria-pressed="${reducedMotion}">&#10024; <span>Motion ${reducedMotion?'reduced':'full'}</span></button><button class="icon-btn" data-action="fullscreen">&#x26F6; <span>Full screen</span></button>${state&&!['setup','results'].includes(state.phase)?'<button class="icon-btn" data-action="pause">&#x275A;&#x275A; <span>Pause</span></button>':''}</div></header>`;
}
function questionSourceOptions(){return '<label class="field-label" for="questionSource">QUESTION SET</label><select class="question-source" id="questionSource"><option value="built-in">Midnight Candy questions (24)</option><option value="custom" '+(customQuestions.length?'':'disabled')+'>My questions ('+customQuestions.length+')</option></select><button class="outline-btn editor-open-btn" data-action="open-editor">&#9998; Create / edit questions</button>'}
function editor(){return renderQuestionEditor(customQuestions,esc,header(),editingQuestionIndex,questionSetName,questionSets,activeSetId,confirmDeleteSet)}
function persistCustomQuestions(){activeSet.questions=customQuestions;activeSet.name=questionSetName;localStorage.setItem(CUSTOM_KEY,JSON.stringify(customQuestions));localStorage.setItem(QUESTION_SET_NAME_KEY,questionSetName);localStorage.setItem(QUESTION_SETS_KEY,JSON.stringify(questionSets));localStorage.setItem(ACTIVE_SET_KEY,activeSetId)}
function activateQuestionSet(id){activeSet=questionSets.find(s=>s.id===id)||activeSet;activeSetId=activeSet.id;customQuestions=activeSet.questions;questionSetName=activeSet.name||'My Halloween questions';persistCustomQuestions()}
function intro() {
 return `${header()}<main class="intro-screen"><div class="intro-moon"></div><div class="intro-mist mist-one"></div><div class="intro-mist mist-two"></div><span class="intro-bat bat-one">&#129415;</span><span class="intro-bat bat-two">&#129415;</span><div class="intro-content"><div class="intro-pumpkin">&#127875;</div><h1>Midnight<br><em>Candy</em></h1><button class="primary-btn intro-start" data-action="open-setup">Enter if you dare <span>&#8594;</span></button></div><div class="intro-ground"></div></main>`;
}
function setup() {
 return `${header()}<main class="setup-layout"><section class="hero"><h1>Midnight<br><em>Candy</em></h1><div class="hero-art"><span class="hero-moon"></span><span class="hero-ghost ghost-a">&#128123;</span><span class="hero-ghost ghost-b">&#129415;</span><span class="hero-pumpkin">&#127875;</span><span class="spark s1">&#10022;</span><span class="spark s2">&#10023;</span><span class="hero-grass"></span></div><div class="feature-row"><span>&#10022; 24 classroom-ready questions</span><span>&#10022; 16 spooky outcomes</span><span>&#10022; Works offline</span></div></section><section class="setup-card"><button class="text-btn setup-back" data-action="return-intro">&#8592; Opening screen</button><div class="card-heading"><div><span class="eyebrow orange">TEACHER SETUP</span><h2>Prepare your game</h2></div><div class="setup-badge">About 1 minute</div></div><label class="field-label">NUMBER OF TEAMS</label><div class="stepper"><button data-action="team-minus" aria-label="Fewer teams">&#8722;</button><strong id="teamCount">4</strong><button data-action="team-plus" aria-label="More teams">+</button><span>teams - choose 2&#8211;6</span></div><div class="team-inputs" id="teamInputs"></div><div class="field-grid"><label><span>STARTING CANDY</span><div class="input-wrap"><input id="startingScore" type="number" min="0" max="999" value="0"><b>&#127852;</b></div></label><label><span>NUMBER OF PUMPKINS</span><div class="input-wrap"><input id="pumpkinCount" type="number" min="1" max="30" value="12"><b>&#127875;</b></div></label></div><div class="question-source-block">${questionSourceOptions()}</div>${oddsPanel()}<button class="primary-btn start-btn" data-action="start">Start the game <span>&#8594;</span></button><p class="microcopy">Your game saves automatically on this device.</p></section></main>`;
}
function renderTeamInputs() {
 const count = +(document.querySelector('#teamCount')?.textContent || 4);
 const el = document.querySelector('#teamInputs'); if (!el) return;
 const source=document.querySelector('#questionSource');if(source){source.value=questionSource;const option=source.querySelector('option[value=custom]');option.disabled=!customQuestions.length;option.textContent='My questions ('+customQuestions.length+')';}
 const old = [...el.querySelectorAll('.team-field input')].map(x => x.value);
 const oldMascots = [...el.querySelectorAll('.team-character')].map(x => x.value);
 el.innerHTML = Array.from({length:count},(_,i)=>`<label class="team-field"><span class="team-dot t${i}"></span><span class="sr-only">Team ${i+1} name</span><input maxlength="18" value="${esc(old[i]||`Team ${i+1}`)}" aria-label="Team ${i+1} name"><select class="team-character" aria-label="Team ${i+1} Halloween character"><option value="random" ${oldMascots[i]===undefined?'selected':''}>&#127922; Random character</option>${QUESTION_MASCOTS.map((mascot,m)=>`<option value="${m}" ${String(oldMascots[i])===String(m)?'selected':''}>${mascot.emoji} ${mascot.name}</option>`).join('')}</select></label>`).join('');
}
function scoreboard(view=state.phase==='question'?'question':'selection') {
 const team=current(),teamIndex=state.teams.indexOf(team),mascot=QUESTION_MASCOTS[team?.mascot??teamIndex%QUESTION_MASCOTS.length];
 const joke=HALLOWEEN_JOKES[Math.floor(Math.random()*HALLOWEEN_JOKES.length)];
 return `<aside class="score-panel"><div class="panel-title"><span>THE SCOREBOARD</span><span class="score-live"><i></i> LIVE</span></div><div class="score-list">${state.teams.map((t,i)=>{const rowMascot=QUESTION_MASCOTS[t.mascot??i%QUESTION_MASCOTS.length];return `<div class="score-row ${t.id===state.currentTeamId?'active':''}"><span class="team-dot t${i%6}"></span><span class="score-team-mascot" role="img" aria-label="${rowMascot.name}" title="${rowMascot.name}">${rowMascot.emoji}</span><span class="score-team">${esc(t.name)}${t.skipTurns?'<small>Haunted turn</small>':''}</span><strong>${t.score}<small> candy</small></strong></div>`}).join('')}</div><div class="score-footer"><button data-action="adjust">+ Adjust scores</button><button data-action="undo" ${state.history?.length?'':'disabled'}>Undo last action</button></div><div class="score-vampire${view==='question'?' score-question-mascot':''}"><span class="score-vampire-face" aria-hidden="true">${mascot.emoji}</span>${view==='question'?'':`<span class="score-vampire-line"><span class="joke-question">${esc(joke.question)}</span><strong>${esc(joke.answer)}</strong></span>`}</div></aside>`;
}
function board() {
 const used = new Set(state.used), team = current();
 return `${header()}<main class="game-layout"><section class="board-area"><div class="turn-banner turn-arrival"><div class="turn-spotlight" aria-hidden="true"></div><div><span class="eyebrow orange">CHOOSE YOUR DESTINY</span><h1 aria-live="polite">${esc(team.name)}<span>'s turn</span></h1></div><div class="turn-candy">&#127852; <b>${team.score}</b><small>CANDY</small></div></div><div class="board-instruction"><span class="instruction-icon">&#10022;</span><span>Choose a glowing pumpkin to reveal your team's question.</span><span class="progress-count"><b>${used.size}</b> / ${state.pumpkinCount} OPENED</span></div><div class="pumpkin-grid">${Array.from({length:state.pumpkinCount},(_,i)=>`<button class="pumpkin-tile ${used.has(i)?'used':''}" data-action="choose-pumpkin" data-index="${i}" ${used.has(i)?'disabled':''} aria-label="${used.has(i)?'Used':'Choose'} pumpkin ${i+1}">${pumpkin(i+1,used.has(i))}<span>${used.has(i)?'OPENED':'PICK ME'}</span></button>`).join('')}</div></section>${scoreboard()}</main><footer class="game-footer"><div class="board-teacher-actions"><button data-action="end-game" class="subtle-btn">End game</button><button data-action="new-game" class="subtle-btn">Start new game</button></div></footer>`;
}
function choiceList(q) {
 const selected=selectedChoice??state.selectedChoice??null,locked=state.answerRevealed||state.resolved!==null;
 return `<div class="choice-grid">${q.choices.map((c,i)=>{const isSelected=selected===i,isCorrect=i===q.answer,revealed=state.answerRevealed;let result='';if(revealed&&isCorrect&&isSelected)result='<b class="choice-result choice-result-good"><span aria-hidden="true">&#10003;</span> YOUR CHOICE · CORRECT ANSWER</b>';else if(revealed&&isCorrect)result='<b class="choice-result choice-result-good"><span aria-hidden="true">&#10003;</span> CORRECT ANSWER</b>';else if(revealed&&isSelected)result='<b class="choice-result choice-result-wrong"><span aria-hidden="true">&#10005;</span> YOUR CHOICE · INCORRECT</b>';return `<button class="choice-btn ${isSelected?'picked':''} ${revealed&&isCorrect?'answer-good':''} ${revealed&&isSelected&&!isCorrect?'answer-wrong':''} ${revealed?'answer-revealed':''}" data-action="choose-answer" data-i="${i}" aria-pressed="${isSelected}" aria-disabled="${locked}" aria-label="${'ABCD'[i]}. ${esc(c)}${revealed&&isCorrect?isSelected?', your choice, correct answer':', correct answer':''}${revealed&&isSelected&&!isCorrect?', your choice, incorrect':''}"><span>${'ABCD'[i]}</span>${esc(c)}${result}</button>`}).join('')}</div>`;
}
function question() {
 const q=state.question, team=current();
 let body = '';
 if(q.type==='build') body = `<div class="jp-prompt">${esc(q.jp)}</div><div class="answer-zone"><span class="zone-label">YOUR SENTENCE</span><div class="word-answer">${selectedWords.map((wi,i)=>`<button class="word-chip selected" data-action="remove-word" data-i="${i}">${esc(q.words[wi])} <small>x</small></button>`).join('')||'<span class="placeholder">Choose the words in order...</span>'}</div><button class="clear-words" data-action="clear-words">Clear sentence</button></div><div class="word-bank">${q.words.map((w,i)=>`<button class="word-chip ${selectedWords.includes(i)?'taken':''}" data-action="add-word" data-i="${i}" ${selectedWords.includes(i)?'disabled':''}>${esc(w)}</button>`).join('')}</div>`;
 else if(q.type==='vocab') body = `<div class="jp-prompt vocab-prompt"><small>WHAT'S THE ENGLISH WORD FOR...</small><strong>${esc(q.jp)}</strong></div>${choiceList(q)}`;
 else if(q.type==='grammar') body = `<div class="prompt-text">${esc(q.prompt)}</div>${choiceList(q)}`;
 else if(q.type==='picture') body = `<div class="picture-question"><p>${esc(q.prompt)}</p><img src="${esc(q.image)}" alt="Picture clue for this question"></div>${choiceList(q)}`;
 else if(q.type==='short') body = `<div class="prompt-text short-answer-prompt">${esc(q.prompt)}</div><div class="teacher-hint">Answer aloud. Your teacher will decide if it is correct.</div>`;
 else if(q.type==='picture-open') body = `<div class="picture-question open-picture-question"><p>${esc(q.prompt)}</p><img src="${esc(q.image)}" alt="Picture clue for this question"></div><div class="teacher-hint">Look carefully and answer aloud. Your teacher will decide if it is correct.</div>`;
 else if(q.type==='mistake') body = state.answerRevealed
  ? `<div class="mistake-comparison"><div class="mistake-line mistake-original"><span>ORIGINAL · INCORRECT</span><p>${highlightChangedText(q.prompt,q.answer,'wrong-word')}</p></div><div class="mistake-line mistake-corrected"><span>CORRECTED SENTENCE</span><p>${highlightChangedText(q.answer,q.prompt,'correct-word')}</p></div></div>${q.note?`<div class="mistake-explanation"><span>WHY IS IT WRONG?</span><p>${esc(q.note)}</p></div>`:''}`
  : `<div class="prompt-text mistake-prompt">${esc(q.prompt)}</div><div class="teacher-hint">Read the sentence carefully. Can you find the mistake?</div>`;
 else body = `<div class="jp-prompt translate-prompt"><small>TRANSLATE THIS SENTENCE INTO ENGLISH</small><strong>${esc(q.jp)}</strong></div><div class="teacher-hint">Say your answer aloud. Your teacher will decide if it is correct.</div>`;
 const answer = ['vocab','grammar','picture'].includes(q.type) ? `${'ABCD'[q.answer]}. ${q.choices[q.answer]}` : q.answer;
 const hint=q.hint?`<div class="question-hint-area">${state.hintRevealed?`<div class="question-hint" role="status"><span>&#128161; HINT</span><p>${esc(q.hint)}</p></div>`:`<button class="hint-btn" data-action="reveal-hint">&#128161; Show a hint</button>`}</div>`:'';
 const cardClasses=['question-card',state.answerRevealed?'answer-revealed':'',q.type==='picture'?'picture-question-card':'',q.type==='picture-open'?'picture-question-card open-picture-question-card':''].filter(Boolean).join(' ');
 return `${header()}<main class="question-layout"><div class="question-sidebar">${scoreboard()}<div class="haunted-house-stage">${HAUNTED_HOUSE_SVG}</div></div><section class="${cardClasses}"><div class="question-meta"><span class="question-type">${TYPE_LABEL[q.type]}</span><span class="level ${q.level.toLowerCase()}">${q.level}</span><span class="q-number">PUMPKIN ${String(state.selectedPumpkin+1).padStart(2,'0')}</span></div><div class="question-team">${pumpkin(state.selectedPumpkin+1)}<span><small>IT'S YOUR TURN</small><b>${esc(team.name)}</b></span></div>${body}${hint}${state.answerRevealed&&q.type!=='mistake'?`<div class="model-answer" aria-live="polite"><span>MODEL ANSWER</span><strong>${esc(answer)}</strong>${q.note?`<small>${esc(q.note)}</small>`:''}</div>`:''}${state.resolved===null?`<div class="question-controls"><button class="outline-btn" data-action="reveal">Reveal answer</button><div class="grade-buttons"><button class="wrong-btn" data-action="grade-no">Incorrect</button><button class="right-btn" data-action="grade-yes" ${q.type==='build'&&!selectedWords.length?'disabled':''}>Correct</button></div></div>`:`<div class="resolved-note ${state.resolved?'good':'bad'}">${state.resolved?'Correct! Choose a Trick or Treat next.':'Not quite. No Candy this time.'}</div><button class="primary-btn continue-btn" data-action="question-continue">${state.resolved?'Choose a Trick or Treat':'Continue'} <span>&#8594;</span></button>`}</section></main>`;
}
function choiceScreen(){const team=current();return `${header()}<main class="choice-screen"><div class="choice-spotlight"></div><span class="eyebrow orange">${esc(team.name)} GOT IT RIGHT</span><h1>Now choose your<br><em>Halloween fate</em></h1><p class="choice-subtitle">Play it steady with a Treat or risk it all with a Trick.</p><div class="fate-options"><button class="fate-card trick-card" data-action="choose-trick"><span class="fate-art">&#128123;</span><span class="fate-kicker">HIGH RISK · HIGH DRAMA</span><strong>TRICK</strong><small>Could win big, lose Candy, steal, swap, or trigger a spooky event.</small><span class="fate-arrow">&#8594;</span></button><button class="fate-card treat-choice" data-action="choose-treat"><span class="fate-art trick-bag">&#127852;</span><span class="fate-kicker">STEADIER · SWEET</span><strong>TREAT</strong><small>Usually a little Candy. A rare roll can hit the jackpot.</small><span class="fate-arrow">&#8594;</span></button></div><div class="choice-score">CURRENT CANDY <b>&#127852; ${team.score}</b></div></main>`}
function trickScreen(){const team=current(),reward=state.trickReward||{points:10,icon:'🍬'},empty=reward.points===0;return `${header()}<main class="trick-screen"><div class="trick-glow"></div><span class="eyebrow orange">${empty?'EMPTY BAG!':'A SWEET TREAT!'}</span><h1>The candy bag<br>has a surprise…</h1><div class="big-candy-bag"><span class="bag-spark spark-left">&#10022;</span><span class="bag-emoji">&#127852;</span><span class="bag-spark spark-right">&#10023;</span></div><section class="trick-prize"><span class="prize-candy">${reward.icon}</span><strong>${empty?'NO CANDY THIS TIME!':`+${reward.points} CANDY!`}</strong><p>${esc(team.name)} ${empty?'found an empty bag. Better luck next time!':'found a sweet stash!'}</p></section><button class="primary-btn trick-continue" data-action="finish-trick">Back to the haunted trail <span>&#8594;</span></button><p class="choice-score">TOTAL CANDY <b>&#127852; ${team.score}</b></p></main>`}
function effectMessage(outcome,before,after,targetId){
 const teamBefore=before.teams.find(t=>t.id===before.currentTeamId),teamAfter=after.teams.find(t=>t.id===after.currentTeamId),targetBefore=before.teams.find(t=>t.id===targetId);
 switch(outcome.effect){
  case'gain':return `${teamAfter.name.toUpperCase()} GAINS +${teamAfter.score-teamBefore.score} CANDY!`;
  case'lose':{const lost=teamBefore.score-teamAfter.score;return lost?`${teamAfter.name.toUpperCase()} LOSES ${lost} CANDY!`:'NO CANDY LEFT TO LOSE!'}
  case'all_gain':return `EVERY TEAM GAINS ${outcome.amount} CANDY!`;
  case'all_lose':{const loss=before.teams.reduce((sum,t)=>sum+Math.min(outcome.amount,t.score),0);return loss?`ALL TEAMS LOSE UP TO ${outcome.amount} CANDY!`:'NO CANDY LEFT TO TAKE!'}
  case'other_lose':return `EVERY OTHER TEAM LOSES UP TO ${outcome.amount} CANDY!`;
  case'swap':return `${teamAfter.name.toUpperCase()} AND ${(after.teams.find(t=>t.id===targetId)?.name||'THE OTHER TEAM').toUpperCase()} SWAP SCORES!`;
  case'steal':{const taken=teamAfter.score-teamBefore.score;return taken?`${taken} CANDY STOLEN FROM ${targetBefore?.name.toUpperCase()||'THE OTHER TEAM'}!`:'THERE WAS NO CANDY LEFT TO STEAL!'}
  case'skip':return `${teamAfter.name.toUpperCase()} WILL SKIP ITS NEXT TURN!`;
  default:return outcome.description.toUpperCase();
 }
}
function impactMarkup(text){return esc(text).replace(/(\+\d+|\b\d+\s+CANDY\b|\b(?:GAINS?|LOSES?|LOST|STOLEN|SWAP(?:PED)?|EVERY|TEAM|TEAMS|NEXT TURN|SKIPPED|UP TO|NO CANDY)\b)/gi,'<strong>$1</strong>')}
function treat(){
 const revealed=Boolean(state.outcome),art=['&#127875;','&#128123;','&#128376;'],labels=['Creepy candy','Ghostly glow','Black cat charm'],clues={jackpot:'A legendary candy stash glimmers inside…',blessing:'The pumpkin spirits stir…',gift:'A witch has left something behind…',golden:'A golden sparkle leaks through…',vampire:'Something with fangs is close…',skeleton:'Bones clatter behind the lid…',swap:'The shadows begin to trade places…',heist:'A masked figure waits in the mist…',mayhem:'Wings flutter overhead…',haunted:'A cold breeze slips out…',moonlit:'A silver glow marks hidden treasure…',blackcat:'A lucky pawprint appears…',bats:'Wings circle above the teams…',graveyard:'Something rattles beneath the soil…',midnight:'A toll echoes through the night…','all-hallows-curse':'A chill sweeps across every team…'};
 const impact=state.eventImpact||(state.outcome?.effect==='swap'||state.outcome?.effect==='steal'?'CHOOSE A TEAM TO SEE WHAT HAPPENS NEXT':state.outcome?.description.toUpperCase());
 return `${header()}<main class="treat-screen ${revealed?'has-reveal event-'+state.outcome.id:''}">${revealed?`<section class="event-reveal"><div class="event-orbit orbit-a"></div><div class="event-orbit orbit-b"></div><span class="event-kicker">A TRICK IS REVEALED</span><div class="event-icon">${state.outcome.icon}</div><h1>${esc(state.outcome.name)}</h1><p class="event-description">${esc(state.outcome.description)}</p><div class="event-score-impact">${impactMarkup(impact)}</div><div class="event-total">${esc(current().name)} · 🍬 ${current().score} CANDY</div></section>`:`<div class="treat-top"><span class="eyebrow orange">ANSWER ACCEPTED · ${esc(current().name.toUpperCase())}</span><h1>Choose a <em>mystery trick</em></h1><p>Three choices. Three different surprises.</p></div><div class="treat-grid">${state.cards.map((c,i)=>{const theme=state.trickCardThemes?.[i]||TRICK_CARD_THEMES[i];return `<button class="treat-card" data-action="pick-treat" data-i="${i}" aria-label="Choose ${esc(theme.label)}: ${esc(theme.clue)}"><span class="treat-number">${String(i+1).padStart(2,'0')}</span><span class="treat-object">${theme.icon}</span><strong>${esc(theme.label)}</strong><small>${esc(theme.clue)}</small></button>`}).join('')}</div><div class="skip-hint">Pick one. There is no telling what the night has planned.</div>`}${revealed&&['swap','steal'].includes(state.outcome.effect)?`<div class="target-picker"><label for="targetTeam">${state.outcome.effect==='swap'?'Choose a team to swap scores with':'Choose a team to steal from'}</label><select id="targetTeam"><option value="">Choose team...</option>${state.teams.filter(t=>t.id!==state.currentTeamId).map(t=>`<option value="${t.id}">${esc(t.name)} (${t.score} Candy)</option>`).join('')}</select><button class="small-primary" data-action="apply-target" ${state.effectApplied?'disabled':''}>Reveal the result</button></div>`:''}${revealed?`<button class="primary-btn continue-btn event-continue" data-action="finish-treat" ${!state.effectApplied?'disabled':''}>Continue <span>&#8594;</span></button>`:''}</main>`;
}
function leaderboard(){const standings=getStandings(state.teams),previous=state.leaderboardPrevious||state.previousLeaderboard||[];return `${header()}<main class="round-leaderboard"><div class="leaderboard-backdrop"></div><span class="eyebrow orange">THE SCOREBOARD SHIFTS</span><h1>Round ${state.roundNumber||1}<br><em>standings</em></h1><p class="leaderboard-intro">Everyone has had a turn. Continue below to choose pumpkins for the next round.</p><section class="leaderboard-table" aria-label="Round ${state.roundNumber||1} leaderboard">${standings.map((team,index)=>{const move=rankMovement(team.id,previous,team.rank),mascot=QUESTION_MASCOTS[team.mascot??index%QUESTION_MASCOTS.length];return `<article class="leaderboard-row ${index===0?'leaderboard-first':''}" style="--row-index:${index}"><span class="leaderboard-rank">${String(team.rank).padStart(2,'0')}</span><span class="leaderboard-mascot" role="img" aria-label="${mascot.name}" title="${mascot.name}">${mascot.emoji}</span><div class="leaderboard-team"><strong>${esc(team.name)}</strong><small>${index===0?'TOP OF THE HAUNTED TRAIL':`POSITION ${team.rank}`}</small></div><b class="leaderboard-score">${team.score}<small> CANDY</small></b><span class="leaderboard-movement ${move.className}" aria-label="${move.detail}">${move.label}</span></article>`}).join('')}</section><button class="primary-btn leaderboard-continue" data-action="continue-leaderboard">Choose pumpkins for Round ${(state.roundNumber||1)+1} <span>&#8594;</span></button></main>`}
function results() {
 const high=Math.max(...state.teams.map(t=>t.score)), winners=state.teams.filter(t=>t.score===high);
 const previous=state.previousLeaderboard||[],standings=getStandings(state.teams);
 return `${header()}<main class="results-screen"><div class="result-confetti">&#10022; &#10023; &#10022; &#10023; &#10022;</div><span class="eyebrow orange">${state.endReason==='teacher'?'THE TEACHER ENDED THE GAME':'THE HAUNTED TRAIL IS COMPLETE'}</span><h1>${winners.length===1?'The winner is...':'It is a tie!'}</h1><div class="winner-name">${winners.map(t=>{const mascot=QUESTION_MASCOTS[t.mascot??state.teams.indexOf(t)%QUESTION_MASCOTS.length];return `<span class="winner-team"><span class="winner-mascot" role="img" aria-label="${mascot.name}">${mascot.emoji}</span>${esc(t.name)}</span>`}).join(' & ')}</div><div class="winner-candy">&#127852; &nbsp;${high} Candy</div>${state.endReason!=='teacher'&&state.requestedPumpkinCount>state.pumpkinCount?`<p class="result-note">This question set had only ${state.pumpkinCount} questions, so the game ended when they were all used. Add more questions for a longer game.</p>`:''}<section class="final-scores"><h2>FINAL SCOREBOARD · POSITION CHANGES</h2>${standings.map((team,i)=>{const move=rankMovement(team.id,previous,team.rank),mascot=QUESTION_MASCOTS[team.mascot??i%QUESTION_MASCOTS.length];return `<div class="final-row"><span class="rank">${String(team.rank).padStart(2,'0')}</span><span class="final-team"><span class="final-mascot" role="img" aria-label="${mascot.name}" title="${mascot.name}">${mascot.emoji}</span>${i===0?'&#127942; ':''}${esc(team.name)} <small class="final-movement ${move.className}">${move.label}</small></span><b>${team.score} <small>candy</small></b></div>`}).join('')}</section><div class="results-actions"><button class="outline-btn" data-action="return-setup">Return to setup</button><button class="primary-btn" data-action="return-setup">Start a new game <span>&#8594;</span></button></div><p class="microcopy">What a wickedly good game. See you next Halloween!</p></main>`;
}
function modal() {
 if(!state?.modal) return '';
 if(state.modal==='pause') return `<div class="modal-backdrop"><section class="modal"><span class="modal-icon">&#127769;</span><h2>Game paused</h2><p>Take a breath. Your progress is saved on this device.</p><button class="primary-btn" data-action="resume">Resume game <span>&#8594;</span></button><button class="text-btn" data-action="end-game">End game and show results</button><button class="text-btn" data-action="new-game">Start a new game</button></section></div>`;
 if(state.modal==='end') return `<div class="modal-backdrop"><section class="modal"><span class="modal-icon">&#127875;</span><h2>End this game?</h2><p>We’ll show the final scores and rankings. Your game results stay saved until you choose a new game.</p><button class="primary-btn" data-action="confirm-end">Show final results <span>&#8594;</span></button><button class="text-btn" data-action="close-modal">Keep playing</button></section></div>`;
 if(state.modal==='adjust') return `<div class="modal-backdrop"><section class="modal"><button class="modal-close" data-action="close-modal">&#215;</button><span class="eyebrow orange">TEACHER CONTROL</span><h2>Adjust Candy</h2><label class="modal-label">TEAM<select id="adjustTeam">${state.teams.map(t=>`<option value="${t.id}">${esc(t.name)} - ${t.score} Candy</option>`).join('')}</select></label><label class="modal-label">CHANGE (+ / -)<input id="adjustAmount" type="number" value="10"></label><button class="primary-btn" data-action="apply-adjust">Apply adjustment <span>&#8594;</span></button></section></div>`;
 return `<div class="modal-backdrop"><section class="modal"><span class="modal-icon">&#127875;</span><h2>Start a new game?</h2><p>Your current game will be replaced. This cannot be undone.</p><button class="primary-btn" data-action="confirm-new">Yes, start fresh <span>&#8594;</span></button><button class="text-btn" data-action="close-modal">Keep playing</button></section></div>`;
}
function render() {
 if(editorOpen){app.innerHTML=editor();return;}
 if(!state){if(pregameScreen==='intro'){app.innerHTML=intro();return;}app.innerHTML=setup();renderTeamInputs();return;}
 const page=state.phase==='board'?board():state.phase==='question'?question():state.phase==='choice'?choiceScreen():state.phase==='trick'?trickScreen():state.phase==='treat'?treat():state.phase==='leaderboard'?leaderboard():results();
 app.innerHTML=page+modal();
}
function shuffle(list){return [...list].sort(()=>Math.random()-.5)}
function startGame() {
 const names=[...document.querySelectorAll('#teamInputs .team-field input')].map((x,i)=>x.value.trim()||`Team ${i+1}`);
 const mascotSelections=[...document.querySelectorAll('#teamInputs .team-character')].map(x=>x.value==='random'?null:Number(x.value));
 const mascots=Array(names.length).fill(null),usedMascots=new Set();
 mascotSelections.forEach((mascot,i)=>{if(Number.isInteger(mascot)&&mascot>=0&&mascot<QUESTION_MASCOTS.length&&!usedMascots.has(mascot)){mascots[i]=mascot;usedMascots.add(mascot);}});
 const unassignedMascots=shuffle(QUESTION_MASCOTS.map((_,i)=>i).filter(i=>!usedMascots.has(i)));
 mascots.forEach((mascot,i)=>{if(mascot===null)mascots[i]=unassignedMascots.pop();});
 const score=Math.max(0,Number(document.querySelector('#startingScore').value)||0);
 const count=Math.min(30,Math.max(1,Number(document.querySelector('#pumpkinCount').value)||12));
 questionSource=document.querySelector('#questionSource')?.value||'built-in';localStorage.setItem(QUESTION_SOURCE_KEY,questionSource);const sourcePool=questionSource==='custom'?customQuestions:QUESTIONS;if(!sourcePool.length){notify('Add some questions first.');return;}const pool=sourcePool.map(q=>({...q,hint:q.hint||QUESTION_HINTS[q.id]||''}));const playableCount=Math.min(count,pool.length);if(playableCount<count)notify(`This set has ${pool.length} questions, so the game will use ${playableCount} pumpkins.`);
 state={version:1,phase:'board',soundEnabled,questionPool:clone(pool),teams:names.map((name,i)=>({id:`team-${i}`,name,score,skipTurns:0,mascot:mascots[i]})),currentTeamId:'team-0',pumpkinCount:playableCount,requestedPumpkinCount:count,used:[],questionOrder:shuffle(pool.map((_,i)=>i)),history:[],modal:null,roundNumber:1};state.previousLeaderboard=standingsSnapshot(state.teams);
 save(state);render();
}
function advance() {
 const previousIndex=state.teams.findIndex(team=>team.id===state.currentTeamId),next=nextTeam(state),nextIndex=next.teams.findIndex(team=>team.id===next.currentTeamId),wrapped=nextIndex<=previousIndex;
 next.question=null;next.outcome=null;next.cards=null;next.resolved=null;next.answerRevealed=false;next.hintRevealed=false;next.chosenCard=null;next.effectApplied=false;next.modal=null;
 if(wrapped&&next.phase==='board'){next.phase='leaderboard';next.roundNumber=state.roundNumber||1;next.leaderboardPrevious=state.previousLeaderboard||standingsSnapshot(state.teams);next.leaderboardCurrent=standingsSnapshot(next.teams);}
 selectedWords=[];selectedChoice=null;commit(next);if(next.phase==='leaderboard')playSound('reveal');else if(next.phase==='board')playSound('turn');
}
render();
document.addEventListener('change',e=>{
 if(e.target.matches('.odds-input')){const group=e.target.dataset.oddsGroup,id=e.target.dataset.oddsId,items=group==='trick'?OUTCOMES:TRICK_PRIZES;let selected=Math.max(0,Math.min(100,Math.round(Number(e.target.value)||0)));const others=items.filter(item=>item.id!==id),remaining=100-selected,oldTotal=others.reduce((sum,item)=>sum+chanceFor(group,item.id),0);prizeOdds[group][id]=selected;const shares=others.map(item=>({id:item.id,share:oldTotal?chanceFor(group,item.id)/oldTotal*remaining:remaining/others.length}));let assigned=0;shares.forEach(item=>{const value=Math.floor(item.share);prizeOdds[group][item.id]=value;item.remainder=item.share-value;assigned+=value});shares.sort((a,b)=>b.remainder-a.remainder).slice(0,remaining-assigned).forEach(item=>prizeOdds[group][item.id]++);localStorage.setItem(PRIZE_ODDS_KEY,JSON.stringify(prizeOdds));document.querySelectorAll(`.odds-input[data-odds-group="${group}"]`).forEach(input=>{input.value=chanceFor(group,input.dataset.oddsId);const output=document.querySelector(`[data-odds-value="${group}-${input.dataset.oddsId}"]`);if(output)output.textContent=`${chanceFor(group,input.dataset.oddsId)}%`});return;}
 if(e.target.id==='questionSource'){questionSource=e.target.value;localStorage.setItem(QUESTION_SOURCE_KEY,questionSource);}
 if(e.target.id==='questionSetName'){questionSetName=e.target.value.trim()||'My Halloween questions';activeSet.name=questionSetName;persistCustomQuestions();e.target.value=questionSetName;}
 if(e.target.id==='savedQuestionSet'){activateQuestionSet(e.target.value);editingQuestionIndex=null;confirmDeleteSet=false;render();notify(`Opened “${questionSetName}”.`);}
 if(e.target.id==='customType'){const choices=['vocab','grammar','picture'].includes(e.target.value);document.querySelector('#customOptions').hidden=!choices;document.querySelector('#customFreeAnswer').hidden=choices;document.querySelector('#customTileChunks').hidden=e.target.value!=='build';document.querySelector('#customPictureField').hidden=!['picture','picture-open'].includes(e.target.value);document.querySelector('#customExplanationLabel').textContent='OPTIONAL GRAMMAR EXPLANATION · WHY IS IT WRONG?';document.querySelector('#customPromptLabel').textContent=({build:'JAPANESE CLUE',vocab:'JAPANESE WORD OR MEANING',grammar:'ENGLISH SENTENCE WITH A BLANK',picture:'QUESTION FOR THE PICTURE',short:'QUESTION · STUDENTS ANSWER ALOUD','picture-open':'QUESTION FOR THE PICTURE · STUDENTS ANSWER ALOUD',mistake:'SENTENCE WITH THE MISTAKE',translate:'JAPANESE SENTENCE TO TRANSLATE'})[e.target.value];document.querySelector('#customPrompt').placeholder=e.target.value==='picture'||e.target.value==='picture-open'?'e.g. What is this?':e.target.value==='short'?'e.g. How are you? What time is it?':'Write your question or clue';}
 if(e.target.id==='customImageFile'&&e.target.files?.[0]){const file=e.target.files[0];if(!file.type.startsWith('image/')){notify('Choose an image file.');return;}if(file.size>12*1024*1024){notify('That image is too large. Choose one under 12 MB.');return;}const reader=new FileReader();reader.onload=()=>{const image=new Image();image.onload=()=>{const scale=Math.min(1,1000/Math.max(image.naturalWidth,image.naturalHeight)),canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));canvas.getContext('2d').drawImage(image,0,0,canvas.width,canvas.height);const data=canvas.toDataURL('image/webp',.8);if(data.length>350000){notify('This picture is still too large after resizing. Try a smaller or simpler image.');return;}document.querySelector('#customImageData').value=data;const preview=document.querySelector('#customImagePreview');preview.src=data;preview.hidden=false;};image.onerror=()=>notify('This image could not be opened. Try a JPG, PNG, or WebP picture.');image.src=String(reader.result);};reader.readAsDataURL(file);}
 if(e.target.id==='questionFile'&&e.target.files?.[0]){const file=e.target.files[0],reader=new FileReader();reader.onload=()=>{try{const list=parseQuestionSet(String(reader.result));if(customQuestions.length&&!confirm('Replace your current custom question set with this file?'))return;customQuestions=list;if(list.setName){questionSetName=list.setName;localStorage.setItem(QUESTION_SET_NAME_KEY,questionSetName);}persistCustomQuestions();questionSource='custom';localStorage.setItem(QUESTION_SOURCE_KEY,'custom');editorOpen=true;render();notify('Question file uploaded.');}catch(err){notify(err.message||'Could not load that file.');}};reader.readAsText(file);e.target.value='';}
});
document.addEventListener('click', e => {
 const button=e.target.closest('[data-action]'); if(!button) return;
 const action=button.dataset.action;
 if(action==='reset-odds'){prizeOdds={trick:{...defaultPrizeOdds.trick},treat:{...defaultPrizeOdds.treat}};localStorage.setItem(PRIZE_ODDS_KEY,JSON.stringify(prizeOdds));document.querySelectorAll('.odds-input').forEach(input=>{input.value=chanceFor(input.dataset.oddsGroup,input.dataset.oddsId);const output=document.querySelector(`[data-odds-value="${input.dataset.oddsGroup}-${input.dataset.oddsId}"]`);if(output)output.textContent=`${input.value}%`;});notify('Prize chances reset to default.');return;}
 if(action==='fullscreen'){if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.();return;}
 if(action==='sound-toggle'){soundEnabled=!soundEnabled;localStorage.setItem('midnight-candy-sound',soundEnabled?'on':'off');button.setAttribute('aria-pressed',String(soundEnabled));button.innerHTML=(soundEnabled?'&#128266;':'&#128263;')+' <span>Sound '+(soundEnabled?'on':'off')+'</span>';return;}
 if(action==='motion-toggle'){reducedMotion=!reducedMotion;localStorage.setItem('midnight-candy-motion',reducedMotion?'reduced':'full');document.documentElement.classList.toggle('reduce-motion',reducedMotion);button.setAttribute('aria-pressed',String(reducedMotion));button.innerHTML='&#10024; <span>Motion '+(reducedMotion?'reduced':'full')+'</span>';return;}
 if(action==='team-plus'||action==='team-minus'){
  const count=document.querySelector('#teamCount');count.textContent=Math.max(2,Math.min(6,Number(count.textContent)+(action==='team-plus'?1:-1)));renderTeamInputs();return;
 }
 if(action==='open-setup'){pregameScreen='setup';render();return;}
 if(action==='return-intro'){pregameScreen='intro';render();return;}
 if(action==='return-setup'){state=null;localStorage.removeItem('midnight-candy-game-v1');selectedWords=[];selectedChoice=null;pregameScreen='setup';render();return;}
 if(action==='start'){startGame();return;}
 if(action==='open-editor'){editorOpen=true;editingQuestionIndex=null;render();return;}
 if(action==='close-editor'){editorOpen=false;editingQuestionIndex=null;render();return;}
 if(action==='use-custom-questions'){if(!customQuestions.length)return;questionSource='custom';localStorage.setItem(QUESTION_SOURCE_KEY,'custom');editorOpen=false;render();notify('Your question set is ready for the next game.');return;}
 if(action==='new-question-set'){const id=`set-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,6)}`;activeSet={id,name:`New question set ${questionSets.length+1}`,questions:[]};questionSets.push(activeSet);activeSetId=id;customQuestions=activeSet.questions;questionSetName=activeSet.name;editingQuestionIndex=null;questionSource='built-in';localStorage.setItem(QUESTION_SOURCE_KEY,'built-in');persistCustomQuestions();render();document.querySelector('#questionSetName')?.select();notify('New question set created. Your other sets are saved.');return;}
 if(action==='confirm-delete-question-set'){confirmDeleteSet=true;editingQuestionIndex=null;render();return;}
 if(action==='cancel-delete-question-set'){confirmDeleteSet=false;render();return;}
 if(action==='delete-question-set'){questionSets=questionSets.filter(set=>set.id!==activeSetId);if(!questionSets.length)questionSets=[{id:`set-${Date.now().toString(36)}`,name:'My Halloween questions',questions:[]}];activeSet=questionSets[0];activeSetId=activeSet.id;customQuestions=activeSet.questions;questionSetName=activeSet.name||'My Halloween questions';confirmDeleteSet=false;editingQuestionIndex=null;questionSource='built-in';localStorage.setItem(QUESTION_SOURCE_KEY,'built-in');persistCustomQuestions();render();notify('Question set deleted.');return;}
 if(action==='edit-custom-question'){editingQuestionIndex=Number(button.dataset.i);render();document.querySelector('.editor-form-card')?.scrollIntoView({behavior:'smooth',block:'start'});document.querySelector('#customPrompt')?.focus();return;}
 if(action==='cancel-custom-edit'){editingQuestionIndex=null;render();return;}
 if(action==='add-custom-question'||action==='save-custom-question'){try{const updated=makeCustomQuestion({type:document.querySelector('#customType').value,prompt:document.querySelector('#customPrompt').value.trim(),answer:document.querySelector('#customAnswer').value.trim(),choicesText:document.querySelector('#customChoiceList')?.value||'',answerIndex:document.querySelector('#customAnswerIndex')?.value||1,level:document.querySelector('#customLevel').value,explanation:document.querySelector('#customExplanation')?.value||'',hint:document.querySelector('#customHint')?.value||'',tileChunksText:document.querySelector('#customTileChunksInput')?.value||'',image:document.querySelector('#customImageData')?.value||''});if(action==='save-custom-question'){updated.id=customQuestions[editingQuestionIndex].id;customQuestions[editingQuestionIndex]=updated;editingQuestionIndex=null;}else customQuestions.push(updated);persistCustomQuestions();render();notify(action==='save-custom-question'?'Question changes saved.':'Question added to your set.');}catch(err){notify(err.message);}return;}
 if(action==='remove-custom-question'){customQuestions.splice(Number(button.dataset.i),1);persistCustomQuestions();if(!customQuestions.length)questionSource='built-in';render();notify('Question removed.');return;}
 if(action==='download-questions'){if(!customQuestions.length){notify('Add a question before saving a file.');return;}downloadQuestionSet(customQuestions,questionSetName);notify('Question file downloaded.');return;}
 if(action==='import-questions'){document.querySelector('#questionFile')?.click();return;}
 if(action==='pause'){state.modal='pause';save(state);render();return;}
 if(action==='resume'||action==='close-modal'){state.modal=null;save(state);render();return;}
 if(action==='end-game'){state.modal='end';render();return;}
 if(action==='new-game'){state.modal='new';render();return;}
 if(action==='confirm-end'){const next=clone(state);next.modal=null;next.phase='results';next.endReason='teacher';next.previousLeaderboard=next.previousLeaderboard||standingsSnapshot(next.teams);next.leaderboardPrevious=next.previousLeaderboard;commit(next);return;}
 if(action==='confirm-new'){state=null;localStorage.removeItem('midnight-candy-game-v1');selectedWords=[];selectedChoice=null;pregameScreen='setup';render();return;}
 if(action==='adjust'){state.modal='adjust';render();return;}
 if(action==='apply-adjust'){
  const before=clone(state),teamId=document.querySelector('#adjustTeam').value,amount=Number(document.querySelector('#adjustAmount').value)||0;
  const team=before.teams.find(t=>t.id===teamId);team.score=Math.max(0,team.score+amount);before.modal=null;commit(before);notify(`${team.name}'s score adjusted.`);return;
 }
 if(action==='undo'){
  if(!state.history?.length)return;
  const history=[...state.history],previous=history.pop();previous.history=history;
  previous.questionPool=state.questionPool;
  if(previous.questionId){previous.question=previous.questionPool?.find(q=>q.id===previous.questionId)||null;delete previous.questionId;}
  if(previous.phase==='treat'&&previous.outcome&&!previous.effectApplied){previous.outcome=null;previous.chosenCard=null;previous.effectApplied=false;}
  state=previous;const saved=save(state);selectedWords=[];selectedChoice=null;render();notify(saved?'Last action undone.':'Last action undone, but browser storage is full; progress may not survive a refresh.');return;
 }
 if(action==='choose-pumpkin'){
  const index=Number(button.dataset.index);if(state.used.includes(index))return;
  const questionIndex=state.questionOrder[state.used.length%state.questionOrder.length],next=clone(state);
  next.used.push(index);next.selectedPumpkin=index;next.question=(next.questionPool||QUESTIONS)[questionIndex];next.phase='question';next.resolved=null;next.answerRevealed=false;next.hintRevealed=false;next.selectedChoice=null;
  selectedWords=[];selectedChoice=null;commit(next);return;
 }
 if(action==='add-word'){const i=Number(button.dataset.i);if(!selectedWords.includes(i))selectedWords.push(i);render();return;}
 if(action==='remove-word'){selectedWords.splice(Number(button.dataset.i),1);render();return;}
 if(action==='clear-words'){selectedWords=[];render();return;}
 if(action==='choose-answer'){if(state.answerRevealed||state.resolved!==null)return;selectedChoice=Number(button.dataset.i);state.selectedChoice=selectedChoice;save(state);render();return;}
 if(action==='reveal-hint'){if(!state.question?.hint)return;state.hintRevealed=true;save(state);render();return;}
 if(action==='reveal'){state.answerRevealed=true;save(state);render();return;}
 if(action==='grade-yes'||action==='grade-no'){if(state.resolved!==null)return;state.resolved=action==='grade-yes';save(state);if(state.resolved)playSound('correct');render();return;}
 if(action==='question-continue'){
  if(state.resolved){const next=clone(state);next.phase='choice';next.cards=null;next.outcome=null;next.chosenCard=null;next.effectApplied=false;commit(next);}
  else advance();return;
 }
 if(action==='choose-trick'){
  const next=clone(state);next.phase='treat';next.cards=chooseDistinctByChance(OUTCOMES,'trick',3);next.trickCardThemes=chooseRandomDistinct(TRICK_CARD_THEMES,3);next.outcome=null;next.chosenCard=null;next.effectApplied=false;commit(next);return;
 }
 if(action==='choose-treat'){
  const next=clone(state),prize=chooseByChance(TRICK_PRIZES,'treat'),reward=prize.points;
  const team=next.teams.find(t=>t.id===next.currentTeamId);team.score+=reward;next.trickReward={points:reward,icon:prize.icon};next.phase='trick';recordHistory(next,state);commit(next,false);playSound('trick');return;
 }
 if(action==='continue-leaderboard'){const next=clone(state);next.phase='board';next.previousLeaderboard=next.leaderboardCurrent||standingsSnapshot(next.teams);next.leaderboardPrevious=null;next.leaderboardCurrent=null;next.roundNumber=(next.roundNumber||1)+1;commit(next);playSound('turn');return;}
 if(action==='finish-trick'){advance();return;}
 if(action==='pick-treat'){
  if(state.outcome)return;
  const before=clone(state),index=Number(button.dataset.i),outcome=before.cards[index];
  if(['swap','steal'].includes(outcome.effect)){state.outcome=outcome;state.chosenCard=index;state.effectApplied=false;state.eventImpact='CHOOSE A TEAM TO REVEAL THE CONSEQUENCE';save(state);render();playPrizeSound(outcome.id);return;}
  const next=applyOutcome(before,outcome);next.outcome=outcome;next.chosenCard=index;next.cards=before.cards;next.eventImpact=effectMessage(outcome,before,next);next.effectApplied=true;recordHistory(next,before);commit(next,false);playPrizeSound(outcome.id);notify('Outcome revealed. Scores updated.');return;
 }
 if(action==='apply-target'){
  if(state.effectApplied)return;
  const targetId=document.querySelector('#targetTeam').value;if(!targetId){notify('Choose a team first.');return;}
  const before=clone(state),next=applyOutcome(before,before.outcome,targetId);next.eventImpact=effectMessage(before.outcome,before,next,targetId);next.outcome=before.outcome;next.chosenCard=before.chosenCard;next.cards=before.cards;next.effectApplied=true;recordHistory(next,before);commit(next,false);notify('Effect applied. Scores updated.');return;
 }
 if(action==='finish-treat'){if(state.effectApplied)advance();return;}
});

